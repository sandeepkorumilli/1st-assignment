package Assignment1;



public class Question2_NumberPattern {
	int n=5;
    public void numbers()
    {
 	   for(int i=1;i<n;i++)
 	   {
 		   for(int j=1;j<n;j++)
 		   {
 			 
 				   System.out.print(i);
 		   }
 		   System.out.println();
 	   }
    }

    public static void main(String args[])
    {
    	Question2_NumberPattern ne = new Question2_NumberPattern();
 	 
 	   ne.numbers();
 	  
    }

}
